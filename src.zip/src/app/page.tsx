'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

interface Question {
  id?: number;
  question: string;
  options: string[];
  answer: string;
}

interface ExamHistory {
  id: string;
  exam_type: string;
  category: string;
  score: number;
  total_questions: number;
  created_at: string;
}

interface UserProfile {
  id: string;
  email: string;
  is_pro: boolean;
  pro_until: string | null;
}

const LOADING_STEPS = [
  '⚡ Membaca kisi-kisi resmi TKA & Kurikulum...',
  '🧠 Merancang narasi soal HOTS & pemecahan masalah...',
  '🎯 Memeriksa variasi opsi A, B, C, D, E...',
  '🚀 Finalisasi paket soal Simulasi TKA...',
];

type Level = 'SD' | 'SMP' | 'SMA/SMK';

export default function Home() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [dailyCount, setDailyCount] = useState<number>(0);
  const maxFreeQuota = 3;

  const [mode, setMode] = useState<'setup' | 'exam' | 'result'>('setup');

  // State Jenjang & Rumpun/Mata Pelajaran
  const [level, setLevel] = useState<Level>('SMA/SMK');
  const [examType, setExamType] = useState<'Saintek' | 'Soshum' | 'Umum'>('Saintek');
  const [subCategory, setSubCategory] = useState('Matematika IPA');
  const [count, setCount] = useState(5);

  const [loading, setLoading] = useState(false);
  const [loadingStepIdx, setLoadingStepIdx] = useState(0);

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [error, setError] = useState('');

  const [explanations, setExplanations] = useState<Record<number, string>>({});
  const [loadingExp, setLoadingExp] = useState<Record<number, boolean>>({});

  const [history, setHistory] = useState<ExamHistory[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showHomeWarningModal, setShowHomeWarningModal] = useState(false);
  const [payLoading, setPayLoading] = useState(false);

  // Otomatis sesuaikan opsi mata pelajaran ketika jenjang atau rumpun berubah
  useEffect(() => {
    if (level === 'SD') {
      setExamType('Umum');
      setSubCategory('Matematika');
    } else if (level === 'SMP') {
      setExamType('Umum');
      setSubCategory('Matematika');
    } else {
      if (examType === 'Umum') setExamType('Saintek');
      setSubCategory(examType === 'Soshum' ? 'Sosiologi' : 'Matematika IPA');
    }
  }, [level, examType]);

  useEffect(() => {
    let interval: any;
    if (loading) {
      setLoadingStepIdx(0);
      interval = setInterval(() => {
        setLoadingStepIdx((prev) => (prev + 1) % LOADING_STEPS.length);
      }, 1500);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const fetchUserData = async (userId: string) => {
    try {
      const { data: profData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profData) setProfile(profData as UserProfile);

      const { data: countData, error: countErr } = await supabase
        .rpc('get_daily_exam_count', { p_user_id: userId });

      if (!countErr && typeof countData === 'number') {
        setDailyCount(countData);
      }
    } catch (err) {
      console.error('Gagal mengambil data user:', err);
    }
  };

  const fetchHistory = async () => {
    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from('exam_results')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        setHistory(data as ExamHistory[]);
      }
    } catch (err) {
      console.error('Gagal mengambil riwayat:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    const checkUserAndRestoreSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const currentUser = session?.user ?? null;
      setUser(currentUser);

      if (currentUser) {
        fetchUserData(currentUser.id);
        fetchHistory();

        const savedSession = localStorage.getItem('pending_exam_session');
        if (savedSession) {
          try {
            const parsed = JSON.parse(savedSession);
            if (parsed && Array.isArray(parsed.questions) && parsed.questions.length > 0) {
              setQuestions(parsed.questions);
              setUserAnswers(parsed.userAnswers || {});
              setExamType(parsed.examType || 'Saintek');
              setSubCategory(parsed.subCategory || '');
              setMode('result');

              let correct = 0;
              parsed.questions.forEach((q: Question, idx: number) => {
                if (parsed.userAnswers[idx] === q.answer) correct++;
              });
              const restoredScore = Math.round((correct / parsed.questions.length) * 100);

              await supabase.from('exam_results').insert([
                {
                  user_id: currentUser.id,
                  exam_type: `${parsed.level || 'SMA'} - ${parsed.examType}`,
                  category: parsed.subCategory,
                  score: restoredScore,
                  total_questions: parsed.questions.length,
                },
              ]);
              fetchHistory();
              fetchUserData(currentUser.id);
            }
          } catch (err) {
            console.error('Gagal memulihkan sesi ujian:', err);
          } finally {
            localStorage.removeItem('pending_exam_session');
          }
        }
      }
    };

    checkUserAndRestoreSession();

    const { data: authListener } = supabase.auth.onAuthStateChange((_event: any, session: any) => {
      const currentUser = session?.user ?? null;
      setUser(currentUser);
      if (currentUser) {
        fetchUserData(currentUser.id);
        fetchHistory();
      } else {
        setProfile(null);
        setHistory([]);
        setDailyCount(0);
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  const handleGoogleLogin = async () => {
    if (mode === 'result' && questions.length > 0) {
      const pendingExamState = {
        questions,
        userAnswers,
        level,
        examType,
        subCategory,
      };
      localStorage.setItem('pending_exam_session', JSON.stringify(pendingExamState));
    }

    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  useEffect(() => {
    if (mode === 'exam' && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (mode === 'exam' && timeLeft === 0) {
      handleFinishExam();
    }
  }, [mode, timeLeft]);

  const handleGoHome = () => {
    if (mode === 'exam') {
      setShowHomeWarningModal(true);
    } else {
      setMode('setup');
    }
  };

  const confirmGoHome = () => {
    setShowHomeWarningModal(false);
    setMode('setup');
  };

  const handlePay = async () => {
    if (!user) {
      alert('Silakan login terlebih dahulu!');
      return;
    }

    setPayLoading(true);

    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          userEmail: user.email,
          amount: 49000,
        }),
      });

      const data = await res.json();

      if (data.success && data.paymentUrl) {
        window.location.href = data.paymentUrl;
      } else {
        alert('Gagal memproses pembayaran: ' + (data.message || 'Terjadi kesalahan'));
      }
    } catch (err) {
      console.error('Checkout error:', err);
      alert('Terjadi kesalahan koneksi ke server.');
    } finally {
      setPayLoading(false);
    }
  };

  const handleStartExam = async (e: React.FormEvent) => {
    e.preventDefault();

    if (count > 5 && !user) {
      alert('Silakan login dengan Google terlebih dahulu untuk mengakses mode 30/50 soal.');
      return;
    }

    if (user && !profile?.is_pro && dailyCount >= maxFreeQuota) {
      setShowUpgradeModal(true);
      return;
    }

    setLoading(true);
    setError('');
    setQuestions([]);
    setExplanations({});

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ level, examType, subCategory, count }),
      });

      const result = await res.json();

      if (!res.ok || !result.success) {
        throw new Error(result.error || 'Gagal terhubung ke pembuat soal AI.');
      }

      if (Array.isArray(result.data) && result.data.length > 0) {
        setQuestions(result.data);
        setUserAnswers({});
        setCurrentIdx(0);
        setTimeLeft(result.data.length * 90);
        setMode('exam');
      } else {
        throw new Error('Format soal yang diterima tidak valid.');
      }

    } catch (err: any) {
      console.error('Error starting exam:', err);
      setError(err.message || 'Terjadi kesalahan saat memuat soal.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAnswer = (option: string) => {
    setUserAnswers({ ...userAnswers, [currentIdx]: option });
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach((q, idx) => {
      if (userAnswers[idx] === q.answer) correct++;
    });
    return Math.round((correct / questions.length) * 100);
  };

  const saveExamResult = async (finalScore: number) => {
    if (!user) return;

    try {
      const { error } = await supabase.from('exam_results').insert([
        {
          user_id: user.id,
          exam_type: `${level} - ${examType}`,
          category: subCategory,
          score: finalScore,
          total_questions: questions.length,
        },
      ]);

      if (!error) {
        fetchHistory();
        fetchUserData(user.id);
      }
    } catch (err) {
      console.error('Error saving result:', err);
    }
  };

  const handleFinishExam = () => {
    const score = calculateScore();
    saveExamResult(score);
    setMode('result');
  };

  const fetchExplanation = async (qIdx: number, questionObj: Question) => {
    if (!user) {
      setShowLoginModal(true);
      return;
    }

    if (explanations[qIdx]) return;

    setLoadingExp((prev) => ({ ...prev, [qIdx]: true }));

    try {
      const res = await fetch('/api/generate-explanation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: questionObj.question,
          options: questionObj.options,
          answer: questionObj.answer,
        }),
      });

      const data = await res.json();
      if (data.success && data.explanation) {
        setExplanations((prev) => ({ ...prev, [qIdx]: data.explanation }));
      }
    } catch (err) {
      console.error('Gagal mengambil pembahasan:', err);
    } finally {
      setLoadingExp((prev) => ({ ...prev, [qIdx]: false }));
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const remainingQuota = Math.max(0, maxFreeQuota - dailyCount);

  return (
    <main className="min-h-screen w-screen bg-[#090D16] text-slate-100 selection:bg-indigo-500 selection:text-white font-sans antialiased relative overflow-y-auto flex flex-col justify-between p-4 sm:p-6 pb-12">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-gradient-to-tr from-indigo-600/15 via-sky-500/10 to-transparent blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-5xl w-full mx-auto flex flex-col min-h-full justify-between gap-6 relative z-10">

        <header className="shrink-0 backdrop-blur-xl bg-slate-900/60 border border-slate-800/80 rounded-2xl px-5 py-3 shadow-xl flex items-center justify-between">
          <button 
            onClick={handleGoHome} 
            className="flex items-center gap-3 text-left hover:opacity-80 transition cursor-pointer focus:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-sky-400 flex items-center justify-center font-black text-white shadow-md shadow-indigo-500/20 text-base">
              ⚡
            </div>
            <div>
              <h1 className="text-base font-black tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
                SIMULASI TKA 2026
              </h1>
              <p className="text-[11px] text-slate-400 font-medium">Platform Simulasi Ujian TKA berbasis AI</p>
            </div>
          </button>

          <div className="flex items-center gap-3">
            {mode !== 'setup' && (
              <button
                onClick={handleGoHome}
                className="text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-semibold px-3 py-1.5 rounded-xl border border-slate-700/60 transition flex items-center gap-1.5 cursor-pointer"
              >
                🏠 Beranda
              </button>
            )}

            {user ? (
              <div className="flex items-center gap-3 bg-slate-800/50 px-3 py-1.5 rounded-xl border border-slate-700/60">
                <div className="text-right">
                  <p className="text-xs font-semibold text-slate-200">{user.user_metadata?.full_name || user.email}</p>
                  {profile?.is_pro ? (
                    <span className="text-[10px] text-amber-400 font-bold flex items-center gap-1 justify-end">
                      👑 Access Pro
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400">
                      Kuota: <strong className="text-indigo-400">{remainingQuota}/{maxFreeQuota}</strong>
                    </span>
                  )}
                </div>
                <button
                  onClick={handleLogout}
                  className="text-xs text-slate-400 hover:text-red-400 font-semibold px-2 py-1 rounded-lg hover:bg-red-500/10 transition cursor-pointer"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleLogin}
                className="inline-flex items-center gap-2 bg-white hover:bg-slate-100 text-slate-900 font-bold text-xs px-4 py-2 rounded-xl transition duration-200 shadow-md active:scale-95 cursor-pointer"
              >
                Masuk dengan Google
              </button>
            )}
          </div>
        </header>

        <div className="flex-1 flex flex-col justify-center my-auto">

          {loading && (
            <div className="w-full max-w-3xl mx-auto space-y-4 animate-pulse">
              <div className="backdrop-blur-xl bg-slate-900/80 border border-indigo-500/30 rounded-xl p-4 shadow-xl flex items-center gap-3">
                <div className="relative w-5 h-5 flex items-center justify-center">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
                </div>
                <div className="flex-1">
                  <p className="text-xs sm:text-sm font-bold text-indigo-300 transition-all duration-300">
                    {LOADING_STEPS[loadingStepIdx]}
                  </p>
                  <p className="text-[10px] text-slate-500">Menyiapkan {count} soal TKA jenjang {level} secara real-time...</p>
                </div>
              </div>

              <div className="backdrop-blur-xl bg-slate-900/40 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="h-4 bg-slate-800 rounded-md w-3/4"></div>
                <div className="h-4 bg-slate-800/60 rounded-md w-1/2"></div>
                
                <div className="space-y-2.5 pt-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="h-10 bg-slate-950/60 border border-slate-800/50 rounded-xl w-full"></div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {mode === 'setup' && !loading && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full">
              
              <div className="md:col-span-2 backdrop-blur-xl bg-slate-900/50 border border-slate-800/80 rounded-2xl p-5 shadow-2xl flex flex-col justify-between">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-3">
                  <div>
                    <h2 className="text-base font-bold text-white tracking-tight">Konfigurasi Simulasi TKA</h2>
                    <p className="text-xs text-slate-400">Pilih jenjang, rumpun, dan mata pelajaran yang diuji</p>
                  </div>
                  {!profile?.is_pro && user && (
                    <button
                      onClick={() => setShowUpgradeModal(true)}
                      className="text-xs bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black px-3 py-1.5 rounded-lg shadow-md hover:scale-105 transition cursor-pointer"
                    >
                      👑 Upgrade Pro
                    </button>
                  )}
                </div>

                {error && (
                  <div className="mb-3 p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl text-xs font-medium">
                    {error}
                  </div>
                )}

                <form onSubmit={handleStartExam} className="space-y-3">
                  
                  {/* PILIHAN JENJANG PENDIDIKAN */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                      Jenjang Pendidikan
                    </label>
                    <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950/70 rounded-xl border border-slate-800/80">
                      {(['SD', 'SMP', 'SMA/SMK'] as Level[]).map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => setLevel(lvl)}
                          className={`py-2 px-3 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                            level === lvl
                              ? 'bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-md'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          {lvl === 'SD' ? '🎒 SD' : lvl === 'SMP' ? '📘 SMP' : '🎓 SMA/SMK'}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* RUMPUN (HANYA UNTUK SMA/SMK) */}
                  {level === 'SMA/SMK' && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                        Rumpun Ujian
                      </label>
                      <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950/70 rounded-xl border border-slate-800/80">
                        <button
                          type="button"
                          onClick={() => {
                            setExamType('Saintek');
                            setSubCategory('Matematika IPA');
                          }}
                          className={`py-2 px-3 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                            examType === 'Saintek'
                              ? 'bg-indigo-600 text-white shadow-md'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          🔬 Saintek
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setExamType('Soshum');
                            setSubCategory('Sosiologi');
                          }}
                          className={`py-2 px-3 rounded-lg font-bold text-xs transition-all cursor-pointer ${
                            examType === 'Soshum'
                              ? 'bg-indigo-600 text-white shadow-md'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          📖 Soshum
                        </button>
                      </div>
                    </div>
                  )}

                  {/* MATA PELAJARAN (DINAMIS SESUAI JENJANG) */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                      Mata Pelajaran
                    </label>
                    <select
                      value={subCategory}
                      onChange={(e) => setSubCategory(e.target.value)}
                      className="w-full bg-slate-950/90 border border-slate-700/80 text-slate-100 font-semibold text-xs rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      {level === 'SD' && (
                        <>
                          <option value="Matematika">Matematika SD</option>
                          <option value="IPA">IPA Terpadu SD</option>
                          <option value="IPS">IPS SD</option>
                          <option value="Bahasa Indonesia">Bahasa Indonesia SD</option>
                        </>
                      )}

                      {level === 'SMP' && (
                        <>
                          <option value="Matematika">Matematika SMP</option>
                          <option value="IPA Terpadu">IPA Terpadu (Fisika/Biologi)</option>
                          <option value="IPS Terpadu">IPS Terpadu (Sejarah/Geografi)</option>
                          <option value="Bahasa Indonesia">Bahasa Indonesia SMP</option>
                          <option value="Bahasa Inggris">Bahasa Inggris SMP</option>
                        </>
                      )}

                      {level === 'SMA/SMK' && examType === 'Saintek' && (
                        <>
                          <option value="Matematika IPA">Matematika IPA</option>
                          <option value="Fisika">Fisika</option>
                          <option value="Kimia">Kimia</option>
                          <option value="Biologi">Biologi</option>
                        </>
                      )}

                      {level === 'SMA/SMK' && examType === 'Soshum' && (
                        <>
                          <option value="Sosiologi">Sosiologi</option>
                          <option value="Sejarah">Sejarah</option>
                          <option value="Geografi">Geografi</option>
                          <option value="Ekonomi">Ekonomi</option>
                        </>
                      )}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                      Jumlah Soal
                    </label>
                    <select
                      value={count}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        if (val > 5 && !user) {
                          alert('Mode 30/50 Soal memerlukan login.');
                        } else if (val > 5 && !profile?.is_pro) {
                          setShowUpgradeModal(true);
                        } else {
                          setCount(val);
                        }
                      }}
                      className="w-full bg-slate-950/90 border border-slate-700/80 text-slate-100 font-semibold text-xs rounded-xl px-3 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value={5}>5 Soal (Quick Test - Free Guest)</option>
                      <option value={30}>
                        30 Soal {profile?.is_pro ? '(Simulasi Standar - ⭐ Pro)' : '(Simulasi Standar - 🔒 Pro)'}
                      </option>
                      <option value={50}>
                        50 Soal {profile?.is_pro ? '(Simulasi Lengkap - ⭐ Pro)' : '(Simulasi Lengkap - 🔒 Pro)'}
                      </option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-indigo-500 via-indigo-600 to-sky-500 hover:from-indigo-600 hover:to-sky-600 text-white font-extrabold py-3 px-4 rounded-xl shadow-lg transition text-xs mt-2 cursor-pointer"
                  >
                    Mulai Simulasi TKA 🚀
                  </button>
                </form>
              </div>

              <div className="backdrop-blur-xl bg-slate-900/50 border border-slate-800/80 rounded-2xl p-4 shadow-2xl flex flex-col min-h-[250px]">
                <h3 className="text-xs font-bold text-white tracking-tight border-b border-slate-800 pb-2 mb-3 flex items-center justify-between">
                  <span>📜 Riwayat Ujian</span>
                  <span className="text-[10px] font-normal text-slate-400">{history.length} Selesai</span>
                </h3>

                <div className="flex-1 overflow-y-auto max-h-[300px] space-y-2 pr-1">
                  {!user ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4">
                      <p className="text-xs text-slate-500">Login dengan Google untuk menyimpan & melihat riwayat nilai.</p>
                    </div>
                  ) : loadingHistory ? (
                    <p className="text-xs text-slate-500 text-center py-4">Memuat riwayat...</p>
                  ) : history.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center p-4">
                      <p className="text-xs text-slate-500">Belum ada tes yang diselesaikan.</p>
                    </div>
                  ) : (
                    history.map((item) => (
                      <div
                        key={item.id}
                        className="p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div className="truncate pr-2">
                          <p className="font-semibold text-slate-200 truncate">{item.category}</p>
                          <p className="text-[10px] text-slate-500">
                            {item.exam_type} • {new Date(item.created_at).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short',
                            })}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="font-black text-indigo-400 text-sm">{item.score}</span>
                          <span className="text-[10px] text-slate-500 block">/ 100</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          )}

          {mode === 'exam' && !loading && questions.length > 0 && (
            <div className="space-y-4 w-full">
              <div className="backdrop-blur-xl bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 shadow-md flex justify-between items-center">
                <span className="text-xs font-bold text-slate-300">
                  Soal <strong className="text-white text-sm">{currentIdx + 1}</strong> / {questions.length}
                </span>
                <div className="text-xs font-mono font-bold bg-amber-500/10 text-amber-400 px-3 py-1 rounded-lg border border-amber-500/20">
                  ⏱ {formatTime(timeLeft)}
                </div>
              </div>

              <div className="backdrop-blur-xl bg-slate-900/40 border border-slate-800/80 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-5">
                <p className="text-white text-sm sm:text-base font-medium leading-relaxed whitespace-pre-line">
                  {questions[currentIdx].question}
                </p>

                <div className="space-y-2.5">
                  {questions[currentIdx].options.map((opt, oIdx) => {
                    const isSelected = userAnswers[currentIdx] === opt;
                    return (
                      <button
                        key={oIdx}
                        onClick={() => handleSelectAnswer(opt)}
                        className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm transition flex items-center justify-between leading-normal cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                            : 'bg-slate-950/40 border-slate-800 text-slate-300 hover:bg-slate-800/40'
                        }`}
                      >
                        <span className="pr-2">{opt}</span>
                        {isSelected && <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 shrink-0 ml-2" />}
                      </button>
                    );
                  })}
                </div>

                <div className="flex justify-between items-center pt-4 border-t border-slate-800/80">
                  <button
                    disabled={currentIdx === 0}
                    onClick={() => setCurrentIdx(currentIdx - 1)}
                    className="px-4 py-2 border border-slate-800 rounded-lg text-xs font-semibold text-slate-400 bg-slate-950/40 hover:bg-slate-800 disabled:opacity-20 cursor-pointer"
                  >
                    Sebelumnya
                  </button>
                  {currentIdx < questions.length - 1 ? (
                    <button
                      onClick={() => setCurrentIdx(currentIdx + 1)}
                      className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs transition shadow-md cursor-pointer"
                    >
                      Selanjutnya
                    </button>
                  ) : (
                    <button
                      onClick={handleFinishExam}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition shadow-md cursor-pointer"
                    >
                      Selesai & Lihat Hasil
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {mode === 'result' && !loading && (
            <div className="space-y-6 max-w-4xl mx-auto w-full">
              <div className="backdrop-blur-xl bg-slate-900/40 border border-slate-800/80 rounded-2xl p-6 shadow-2xl text-center space-y-4">
                <span className="text-slate-400 font-bold text-xs uppercase tracking-widest">Hasil Simulasi TKA ({level})</span>
                <div className="text-5xl font-black bg-gradient-to-r from-indigo-400 to-emerald-400 bg-clip-text text-transparent">
                  {calculateScore()} <span className="text-base text-slate-500 font-normal">/ 100</span>
                </div>

                {!user && (
                  <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-xs text-indigo-300 max-w-md mx-auto">
                    💡 <strong>Ingin melihat pembahasan & menyimpan riwayat?</strong> Masuk dengan Google secara gratis untuk membuka fitur pembahasan AI!
                  </div>
                )}

                <button
                  onClick={() => setMode('setup')}
                  className="w-full max-w-md bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl text-xs transition mx-auto block cursor-pointer"
                >
                  Kembali ke Menu Utama
                </button>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-300 flex items-center justify-between border-b border-slate-800 pb-2">
                  <span>📖 Review Jawaban & Pembahasan</span>
                  {!user && <span className="text-xs text-amber-400 font-medium">🔒 Login untuk Buka Pembahasan</span>}
                </h3>

                {questions.map((q, idx) => {
                  const userAnswer = userAnswers[idx];
                  const isCorrect = userAnswer === q.answer;

                  return (
                    <div
                      key={idx}
                      className="backdrop-blur-xl bg-slate-900/50 border border-slate-800 rounded-2xl p-5 space-y-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <span className="text-xs font-bold text-indigo-400">Soal #{idx + 1}</span>
                        <span
                          className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                            isCorrect
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : 'bg-red-500/10 text-red-400 border border-red-500/20'
                          }`}
                        >
                          {isCorrect ? '✓ Benar' : '✕ Salah / Tidak Diisi'}
                        </span>
                      </div>

                      <p className="text-white text-xs sm:text-sm leading-relaxed whitespace-pre-line">{q.question}</p>

                      <div className="text-xs space-y-1 bg-slate-950/50 p-3 rounded-xl border border-slate-800/80">
                        <p className="text-slate-400">
                          Jawaban Kamu:{' '}
                          <span className={isCorrect ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>
                            {userAnswer || 'Tidak Dijawab'}
                          </span>
                        </p>
                        <p className="text-slate-400">
                          Kunci Jawaban: <span className="text-emerald-400 font-bold">{q.answer}</span>
                        </p>
                      </div>

                      <div className="pt-2">
                        {explanations[idx] ? (
                          <div className="p-4 bg-indigo-950/30 border border-indigo-500/30 rounded-xl space-y-1.5 text-xs">
                            <span className="font-bold text-indigo-300 flex items-center gap-1.5">
                              💡 Pembahasan AI:
                            </span>
                            <p className="text-slate-300 leading-relaxed whitespace-pre-line">{explanations[idx]}</p>
                          </div>
                        ) : (
                          <button
                            onClick={() => fetchExplanation(idx, q)}
                            disabled={loadingExp[idx]}
                            className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
                              !user
                                ? 'bg-slate-800/80 hover:bg-slate-800 text-amber-400 border border-amber-500/30'
                                : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                            }`}
                          >
                            {loadingExp[idx] ? (
                              <span>⏳ AI sedang merancang pembahasan...</span>
                            ) : !user ? (
                              <span>🔒 Login Google untuk Buka Pembahasan</span>
                            ) : (
                              <span>✨ Tampilkan Pembahasan Lengkap AI</span>
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* MODAL POP-UP WARNING KELUAR SIMULASI */}
        {showHomeWarningModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="bg-slate-900 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative border border-slate-800 text-center">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto text-amber-400 text-2xl">
                ⚠️
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-black text-white">Batalkan Simulasi Ujian?</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Ujian kamu sedang berlangsung. Jika kembali ke beranda sekarang, seluruh progres dan jawaban ujian akan hilang.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => setShowHomeWarningModal(false)}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold py-2.5 rounded-xl transition text-xs cursor-pointer"
                >
                  Lanjutkan Ujian
                </button>
                <button
                  onClick={confirmGoHome}
                  className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-2.5 rounded-xl transition text-xs shadow-lg shadow-red-600/20 cursor-pointer"
                >
                  Ya, Keluar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MODAL POP-UP LOGIN GOOGLE */}
        {showLoginModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="bg-slate-900 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative border border-slate-800 text-center">
              <button
                onClick={() => setShowLoginModal(false)}
                className="absolute top-3 right-3 text-slate-400 hover:text-white font-bold text-base cursor-pointer"
              >
                ✕
              </button>
              <div className="space-y-2">
                <span className="text-3xl">🔑</span>
                <h3 className="text-base font-black text-white">Login Gratis untuk Buka Pembahasan</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Dapatkan pembahasan rinci berbasis AI dan simpan riwayat ujianmu dengan login akun Google.
                </p>
              </div>
              <button
                onClick={handleGoogleLogin}
                className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3 rounded-xl shadow-lg transition text-xs flex items-center justify-center gap-2 cursor-pointer"
              >
                Masuk dengan Google
              </button>
            </div>
          </div>
        )}

        {/* MODAL POP-UP UPGRADE PRO */}
        {showUpgradeModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <div className="bg-slate-900 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl relative border border-slate-800">
              <button
                onClick={() => setShowUpgradeModal(false)}
                className="absolute top-3 right-3 text-slate-400 hover:text-white font-bold text-base cursor-pointer"
              >
                ✕
              </button>
              <div className="text-center space-y-1">
                <span className="bg-amber-500/10 text-amber-400 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-500/20">
                  ⭐ AKSES SIMULASI TKA PRO 2026
                </span>
                <h3 className="text-lg font-black text-white">Buka Akses Tryout Tanpa Batas!</h3>
              </div>
              <button
                onClick={handlePay}
                disabled={payLoading}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black py-3 rounded-xl shadow-lg transition text-xs disabled:opacity-50 cursor-pointer"
              >
                {payLoading ? 'Memproses...' : 'Unlock Akses Pro (Rp 49.000)'}
              </button>
            </div>
          </div>
        )}

      </div>
    </main>
  );
}