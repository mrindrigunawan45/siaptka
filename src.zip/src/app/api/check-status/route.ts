import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

export async function POST(req: Request) {
  try {
    const { invoiceNumber, userId } = await req.json();

    if (!invoiceNumber) {
      return NextResponse.json({ success: false, message: 'Nomor invoice diperlukan.' }, { status: 400 });
    }

    const clientId = process.env.DOKU_CLIENT_ID;
    const secretKey = process.env.DOKU_SECRET_KEY;
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

    if (!clientId || !secretKey || !supabaseUrl || !serviceRoleKey) {
      return NextResponse.json({ success: false, message: 'Kredensial server tidak lengkap.' }, { status: 500 });
    }

    const requestId = `REQ-CHECK-${Date.now()}`;
    const targetPath = `/orders/v1/status/${invoiceNumber}`;
    const requestTimestamp = new Date().toISOString().slice(0, 19) + 'Z';

    // Signature khas DOKU untuk Status Inquiry
    const signatureRaw = `Client-Id:${clientId}\nRequest-Id:${requestId}\nRequest-Timestamp:${requestTimestamp}\nRequest-Target:${targetPath}`;
    const signature = crypto.createHmac('sha256', secretKey).update(signatureRaw).digest('base64');

    // 1. Tanya langsung ke DOKU
    const resDoku = await fetch(`https://api.doku.com${targetPath}`, {
      method: 'GET',
      headers: {
        'Client-Id': clientId,
        'Request-Id': requestId,
        'Request-Timestamp': requestTimestamp,
        'Signature': `HMACSHA256=${signature}`,
      },
    });

    const dokuData = await resDoku.json();
    console.log('[DOKU STATUS INQUIRY RESP]:', dokuData);

    const rawStatus = dokuData.transaction?.status || dokuData.order?.status;
    const isPaid = ['SUCCESS', 'SUCCESSFUL', 'PAID', 'SETTLED', '0000', '00'].includes(
      String(rawStatus || '').toUpperCase()
    );

    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    if (isPaid) {
      const proUntilDate = new Date();
      proUntilDate.setFullYear(proUntilDate.getFullYear() + 1);

      // A. Jika userId dikirimkan dari frontend, langsung update profil user tersebut
      let targetUserId = userId;

      // B. Jika userId tidak terdeteksi dari frontend, cari userId dari tabel transactions berdasarkan invoice_number
      if (!targetUserId) {
        const { data: tx } = await supabaseAdmin
          .from('transactions')
          .select('user_id')
          .eq('invoice_number', invoiceNumber)
          .single();
        if (tx) targetUserId = tx.user_id;
      }

      // C. Update tabel profiles menjadi PRO
      if (targetUserId) {
        await supabaseAdmin
          .from('profiles')
          .update({
            is_pro: true,
            pro_until: proUntilDate.toISOString(),
          })
          .eq('id', targetUserId);
      }

      // D. Update status transaksi menjadi SUCCESS di database
      await supabaseAdmin
        .from('transactions')
        .update({ status: 'SUCCESS' })
        .eq('invoice_number', invoiceNumber);

      return NextResponse.json({
        success: true,
        isPaid: true,
        message: 'Pembayaran terkonfirmasi LUNAS! Status akun kamu sudah menjadi PRO.',
      });
    }

    return NextResponse.json({
      success: false,
      isPaid: false,
      message: `Status pembayaran saat ini: ${rawStatus || 'PENDING'}`,
    });
  } catch (err: any) {
    console.error('[CHECK STATUS ERROR]:', err);
    return NextResponse.json({ success: false, message: err.message }, { status: 500 });
  }
}