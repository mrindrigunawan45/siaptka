import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

export async function POST(req: Request) {
  try {
    const { userId, userEmail, amount } = await req.json();

    if (!userId) {
      return NextResponse.json(
        { success: false, message: 'User ID tidak ditemukan.' },
        { status: 400 }
      );
    }

    const clientId = process.env.DOKU_CLIENT_ID;
    const secretKey = process.env.DOKU_SECRET_KEY;
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://siapcpns.vercel.app';

    if (!clientId || !secretKey || !supabaseUrl || !serviceRoleKey) {
      return NextResponse.json(
        { success: false, message: 'Kredensial server tidak lengkap.' },
        { status: 500 }
      );
    }

    const requestId = `REQ-${Date.now()}`;
    const invoiceNumber = `INV-${Date.now()}`;
    const targetPath = '/checkout/v1/payment';
    const dokuHost = 'https://api.doku.com';

    // 1. Simpan relasi Invoice ke User ID di Supabase (Tabel transactions)
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);
    const { error: dbError } = await supabaseAdmin
      .from('transactions')
      .insert({
        invoice_number: invoiceNumber,
        user_id: userId,
        amount: amount || 49000,
        status: 'PENDING',
      });

    if (dbError) {
      console.error('[CHECKOUT DB ERROR]:', dbError);
      return NextResponse.json(
        { success: false, message: `Gagal mencatat transaksi: ${dbError.message}` },
        { status: 500 }
      );
    }

    const redirectSuccessUrl = `${appUrl}/payment-success?invoice=${invoiceNumber}`;
    const notificationEndpoint = `${appUrl}/api/webhooks`;

    // 2. Buat Payload Resmi DOKU SNAP V1.1 dengan Auto Redirect & Callback URL
    const body = {
      order: {
        invoice_number: invoiceNumber,
        amount: amount || 49000,
        callback_url: redirectSuccessUrl,
        auto_redirect: true,
      },
      payment: {
        payment_due_date: 60,
      },
      customer: {
        id: userId,
        email: userEmail || 'user@example.com',
      },
      url: {
        return_url: redirectSuccessUrl,
        callback_url: redirectSuccessUrl,
        notification_url: notificationEndpoint,
      },
    };

    const bodyJson = JSON.stringify(body);

    const digest = crypto.createHash('sha256').update(bodyJson).digest('base64');
    const requestTimestamp = new Date().toISOString().slice(0, 19) + 'Z';
    const signatureRaw = `Client-Id:${clientId}\nRequest-Id:${requestId}\nRequest-Timestamp:${requestTimestamp}\nRequest-Target:${targetPath}\nDigest:${digest}`;
    const signature = crypto.createHmac('sha256', secretKey).update(signatureRaw).digest('base64');

    const response = await fetch(`${dokuHost}${targetPath}`, {
      method: 'POST',
      headers: {
        'Client-Id': clientId,
        'Request-Id': requestId,
        'Request-Timestamp': requestTimestamp,
        'Signature': `HMACSHA256=${signature}`,
        'Content-Type': 'application/json',
      },
      body: bodyJson,
    });

    const data = await response.json();

    if (response.ok && data.response?.payment?.url) {
      return NextResponse.json({
        success: true,
        paymentUrl: data.response.payment.url,
      });
    }

    return NextResponse.json(
      { success: false, message: data.error?.message || 'DOKU Request Refused' },
      { status: 400 }
    );
  } catch (err: any) {
    return NextResponse.json(
      { success: false, message: err.message || 'Server Error' },
      { status: 500 }
    );
  }
}