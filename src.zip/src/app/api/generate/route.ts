import { NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function generateWithRetry(prompt: string, maxRetries = 3) {
  const models = [
    'gemini-3.5-flash-lite',
    'gemini-3.7-flash',
    'gemini-3.8-flash',
  ];

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const selectedModel = models[attempt % models.length];
    
    try {
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      if (response.text) {
        return response.text;
      }
    } catch (err: any) {
      console.warn(`[Attempt ${attempt + 1}] Model ${selectedModel} sibuk. Mencoba opsi berikutnya...`);

      if (attempt === maxRetries - 1) throw err;
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }

  throw new Error('Server AI sedang padat. Silakan coba lagi.');
}

function getTKASubjectConstraints(grade: string, subject: string): string {
  const sub = subject.toLowerCase();

  if (sub.includes('indonesia')) {
    return `ATURAN TKA BAHASA INDONESIA (${grade}):
- Teks wajib 100% Bahasa Indonesia.
- 70% Soal HOTS berbasis Teks Bacaan (Paragraf 2-3 kalimat/cerita/artikel).
- Fokus Materi: Ide pokok, simpulan bacaan, makna kata/istilah, struktur kalimat, dan analisis bacaan.
- Sesuaikan kompleksitas bahasa dengan jenjang ${grade}.`;
  }

  if (sub.includes('inggris')) {
    return `ATURAN TKA BAHASA INGGRIS (${grade}):
- Seluruh teks (bacaan, pertanyaan, opsi) WAJIB FULL BAHASA INGGRIS.
- 70% Soal HOTS berbasis Reading Passage (2-3 paragraf).
- Tanyakan Main Idea, Word Reference, Inference, Vocabulary in context, dan Grammar dasar/lanjut.`;
  }

  if (sub.includes('matematika') || sub.includes('mtk')) {
    return `ATURAN TKA MATEMATIKA (${grade}):
- Teks wajib 100% Bahasa Indonesia.
- Sertakan narasi soal cerita/studi kasus nyata (Numerasi).
- Fokus Materi (${grade}): Aritmatika, Aljabar, Geometri, Pengolahan Data/Statistik dasar.`;
  }

  return `ATURAN TKA MAPEL PILIHAN (${subject} - ${grade}):
- Teks wajib 100% Bahasa Indonesia.
- Gunakan soal berbasis analisis konsep, studi kasus, dan pemecahan masalah (HOTS) sesuai kurikulum ${grade}.`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    
    // Menerima parameter fleksibel (level/grade, subCategory/subject, examType)
    const { level, grade, examType, subCategory, subject, count = 5 } = body;
    
    const selectedLevel = level || grade || 'Kelas 12 SMA';
    const selectedSubject = subCategory || subject || 'Matematika';

    const subjectRule = getTKASubjectConstraints(selectedLevel, selectedSubject);

    const isSD = selectedLevel.toString().toUpperCase().includes('SD');
    const optionRule = isSD 
      ? 'Buatkan tepat 4 Opsi Jawaban (A, B, C, D) karena jenjang SD.' 
      : 'Buatkan tepat 5 Opsi Jawaban (A, B, C, D, E) untuk jenjang SMP/SMA/SMK.';

    const prompt = `Kamu adalah pakar penyusun soal Tes Kemampuan Akademik (TKA) resmi Pusmendik Kemendikdasmen.
Buatkan ${count} soal pilihan ganda standar TKA untuk tingkat ${selectedLevel} pada mata pelajaran ${selectedSubject} ${examType ? `(Rumpun/Ujian: ${examType})` : ''}.

ATURAN UTAMA:
1. DILARANG KERAS menanyakan definisi/teori abstrak. Gunakan pendekatan studi kasus, cerita, atau analisis data/bacaan (HOTS).
2. ${optionRule}
3. Pastikan nilai kunci jawaban di "answer" persis sama dengan salah satu pilihan yang ada di array "options".

${subjectRule}

Format output WAJIB berupa ARRAY JSON murni:
[
  {
    "id": 1,
    "question": "Narasi bacaan/soal...",
    "options": ${isSD ? '["A. ...", "B. ...", "C. ...", "D. ..."]' : '["A. ...", "B. ...", "C. ...", "D. ...", "E. ..."]'},
    "answer": "A. ..."
  }
]
Catatan: JANGAN buat pembahasan di JSON ini agar respon secepat mungkin.`;

    const rawText = await generateWithRetry(prompt);

    const cleanedText = rawText
      .replace(/```json/g, '')
      .replace(/```/g, '')
      .trim();

    const questionsData = JSON.parse(cleanedText);

    return NextResponse.json({
      success: true,
      data: questionsData,
    });

  } catch (error: any) {
    console.error('API Error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Gagal membuat soal TKA. Silakan coba lagi.',
      },
      { status: 500 }
    );
  }
}