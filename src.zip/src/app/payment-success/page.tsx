'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { createClient } from '@supabase/supabase-js';

function PaymentSuccessContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  // Client Supabase standar
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  const [loading, setLoading] = useState(true);
  const [statusMessage, setStatusMessage] = useState('Memverifikasi status pembayaran...');
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    async function verifyPayment() {
      try {
        const { data: { user } } = await supabase.auth.getUser();

        if (!user) {
          setStatusMessage('Silakan login terlebih dahulu untuk memverifikasi pembayaran.');
          setLoading(false);
          return;
        }

        const invoiceNumber = searchParams.get('invoice') || searchParams.get('order_id');

        if (!invoiceNumber) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('is_pro')
            .eq('id', user.id)
            .single();

          if (profile?.is_pro) {
            setIsSuccess(true);
            setStatusMessage('Selamat! Akun kamu sudah berstatus PRO.');
          } else {
            setStatusMessage('Nomor invoice tidak ditemukan di URL.');
          }
          setLoading(false);
          return;
        }

        const res = await fetch('/api/check-status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            invoiceNumber,
            userId: user.id,
          }),
        });

        const data = await res.json();

        if (data.isPaid && data.success) {
          setIsSuccess(true);
          setStatusMessage('Pembayaran Berhasil! Akun kamu sudah aktif sebagai PRO.');
        } else {
          setStatusMessage(data.message || 'Pembayaran belum terkonfirmasi.');
        }
      } catch (err: any) {
        console.error('Error verifying payment:', err);
        setStatusMessage(`Gagal verifikasi: ${err.message || 'Server error'}`);
      } finally {
        setLoading(false);
      }
    }

    verifyPayment();
  }, [searchParams, supabase, router]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 text-center border border-gray-200">
        {loading ? (
          <div className="py-6">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-700 font-medium text-base">{statusMessage}</p>
          </div>
        ) : isSuccess ? (
          <div className="py-4">
            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl font-bold">
              ✓
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Pembayaran Sukses!</h2>
            <p className="text-gray-600 mb-6 text-sm">{statusMessage}</p>
            <button
              onClick={() => router.push('/')}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition"
            >
              Mulai Belajar
            </button>
          </div>
        ) : (
          <div className="py-4">
            <div className="w-16 h-16 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl font-bold">
              !
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Status Pembayaran</h2>
            <p className="text-gray-600 mb-6 text-sm bg-gray-50 p-3 rounded-lg border border-gray-200 text-left font-mono break-words">
              {statusMessage}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-gray-900 text-white py-3 rounded-xl font-semibold hover:bg-gray-800 transition"
            >
              Cek Ulang Status
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function PaymentSuccessPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-gray-500">Memuat halaman...</div>}>
      <PaymentSuccessContent />
    </Suspense>
  );
}